getal = int(input("Noem een getal waar je de tafel van wilt zien? "))
for i in range(1,11):
    print(getal,"x",i, "=", i * getal)